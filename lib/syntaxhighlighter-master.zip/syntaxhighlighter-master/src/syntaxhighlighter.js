// window.SyntaxHighlighter = {
//   brushes: {},

//   Highlighter: require('syntaxhighlighter-brush').Brush,

//   highlight: function()
//   {

//   },

//   all: function()
//   {

//   }
// };

window.XRegExp = require('xregexp');
window.SyntaxHighlighter = require('./core');
